import React, {useState} from 'react'

export const ControlButton = () => {
    const [counter,setCounter]=useState(0);

    //increase Counter
    const increase= ()=> {
        setCounter(count => count+1)
    }
    //decrease counter
    const decrease = ()=>{
      if (counter>0){
        setCounter(count=> count-1)}
    }
    //reset counter
    const reset=()=>{
        setCounter(0)
    }
  return (
    <>
    <div><span className="counter__output">{counter}</span></div>
    <div className="btn__container">
        
        <button className="control__btn" onClick={increase}>Increase </button>
        <button className="control__btn" onClick={decrease}> Decrease </button>
        <button className="reset" onClick={reset}>Reset</button>
      </div>
      </> )
}
