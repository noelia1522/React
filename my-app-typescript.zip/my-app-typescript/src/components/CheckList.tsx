import e from "express";
import { setUncaughtExceptionCaptureCallback } from "process";
import React, { useState } from "react";
import "./CheckedList.css"

type checkProps = {
    data: {
        id: string,
        name: string,
        checked: boolean
    }[]
}
export const CheckList = ({data}: checkProps) => {
    const [check, checkCheckbox] = useState(data);
function isChecked (id:any) {
    const newCheckList = [...check]
    newCheckList.map(item =>{if(item.id === id) item.checked = !item.checked} )
    checkCheckbox(newCheckList)
}
  return (
    <div>
        <h1>Your Checklist:</h1>
      
        {data.map((item,index) => {
            
            return (
                <div>
                    <input type="checkbox" id={item.id} onChange={()=>isChecked(item.id)}></input>
                
                    {item.checked===true ? <span className="checked-item">{item.name}</span> : <span className="check">{item.name}</span>}
                    
                </div>
            )
        })}
    </div>
    
)
}
