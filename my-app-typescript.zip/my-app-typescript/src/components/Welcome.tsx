import React from 'react'

type WelcomeProps = {
    children : React.ReactElement;
}


export const Welcome = (props: WelcomeProps) => {
  return (
    <div>Welcome</div>
  )
}
