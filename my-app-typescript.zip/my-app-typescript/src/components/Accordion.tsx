import { title } from "process";
import React, { useState,ReactNode } from "react";

type AccordionProps = {
        title: string,
        content: ReactNode
}

function Accordion({data}: {data:AccordionProps} ){
    return <ul className="accordion">
        <li className="accordion-item">
            <h2 className="accordion-item-title">
                <button className="accordion-item-btn">
                    {data.title}
                </button>
            </h2>
            <div className="accordion-item-content">{data.content}</div>
        </li>
    </ul>
}
export default Accordion;
