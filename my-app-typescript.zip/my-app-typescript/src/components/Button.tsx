import React, { Children } from 'react'
type ButtonProps ={
  number: Number
}

export const Button = (props:ButtonProps)=> {
           //this.updateQuantity = this.updateQuantity.bind(this)
        return(
            <div>
               <button onClick= {()=>alert(`Button ${props.number} clicked`)}>Click</button>
            </div>
        )}