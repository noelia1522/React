import React from 'react'

export const Button = () => {
    alert ("This is an alert!") 
  return (
    <div> 
        <button onClick={alert} type="button"> Click me! </button>
    </div>
  )
}
