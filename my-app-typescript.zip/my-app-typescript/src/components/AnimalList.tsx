import React from 'react'
import { isEmptyBindingElement } from 'typescript'

type AnimalProps ={
    list:{
        name:string
    }[]

}
export const AnimalList = ({list}: AnimalProps) => {
  return (
    <div>
    <h1>Animal List:</h1>
    {list.map((element)=>{
        return(
            <div>   
            
            <p>{element.name}</p>
            </div>
        )
    })}</div>
  )
}
