import React from 'react'

type GreetingsProps = {
  firstname: string,
  lastname: string,
  city: string,
  isLoggedIn ?: boolean,
  messageCount?: number
}

export const Greetings = ({firstname,lastname,city,isLoggedIn,messageCount = 0}: GreetingsProps) => {
  return (
    <div> {isLoggedIn ?  `Welcome ${firstname} ${lastname} from ${city}! You have ${messageCount} unread messages!`: `Welcome Guest!` }</div>
    //<div>Hello {props.firstname} {props.lastname} from {props.city}</div>
  )
}
