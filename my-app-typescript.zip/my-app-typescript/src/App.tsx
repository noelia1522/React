import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Greetings } from './components/Greetings';
import { Heading } from './components/Heading';
import { Welcome } from './components/Welcome';
import { Status } from './components/Status';
import { PersonList } from './components/PersonList';
import { Container } from './components/Container';
import { Button } from './components/Button';



function App() {
  const nameList = [
    {
      first: "Nath",
      last: "Martin"
    },
    {
      first: "Noe",
      last: "Lopez"
    },
    {
      first: "Sana",
      last: "Minatozaki"
    },{
      first: "Mina",
      last: "Miyoi"
    }
  ]

  const currDate = new Date().toLocaleDateString();


  return (
    
    <Container styles = {{border: '3px solid black', margin :'2rem'}}>
      <p>Today is: {currDate}</p>
      <Welcome>
      <Heading>Welcome to Web Development with React!</Heading>
      </Welcome>
      <Greetings
        firstname="Nath"
        lastname="Martin"
        city="Barcelona"
        messageCount = {22}
        isLoggedIn={true}></Greetings>
        <Status status = "loading"></Status>
        <PersonList names = {nameList}></PersonList>
        <Button ></Button>
    </Container>
  );
}

export default App;
