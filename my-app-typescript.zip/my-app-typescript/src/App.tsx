import react from 'react';
import logo from './logo.svg';
import './App.css';
import { Greetings } from './components/Greetings';
import { Heading } from './components/Heading';
import { Welcome } from './components/Welcome';
import { Status } from './components/Status';
import { PersonList } from './components/PersonList';
import { Container } from './components/Container';
import { Button } from './components/Button';
import { AnimalList } from './components/AnimalList';
import { Clock } from './components/Clock';
import {useState} from "react"
import { ControlButton } from './components/ControlButton';
import { CheckList } from './components/CheckList';
import Accordion from './components/Accordion'

function App() {

const task=[{
  id: "1",
  name: "run",
  checked: false
},

{
  id: "2",
  name: "walk",
  checked: false
}]

  const nameList = [
    {
      first: "Nath",
      last: "Martin"
    },
    {
      first: "Noe",
      last: "Lopez"
    },
    {
      first: "Sana",
      last: "Minatozaki"
    }, {
      first: "Mina",
      last: "Miyoi"
    }
  ]

  const currDate = new Date().toLocaleDateString();

  const buttonHandler = (e: any) => {
    alert("This is an alert!")
    e.preventDefault()

  }

  const animal = [
    {
      name: "cat"
    },
    {
      name: "cow"
    },
    {
      name: "dog"
    }, {
      name: "penguin"
    }
  ]

  

  return (
    <Container styles={{ border: '3px solid black', margin: '2rem' }}>
      <Clock></Clock>
      <h1>Today is: {currDate}</h1>
      <Welcome>
        <Heading>Welcome to Web Development with React!</Heading>
      </Welcome>
      <Greetings
        firstname="Nath"
        lastname="Martin"
        city="Barcelona"
        messageCount={22}
        isLoggedIn={true}></Greetings>
      <Status status="loading"></Status>
      <PersonList names={nameList}></PersonList>
      <div>
        <Button number={1}></Button>
        <Button number={2}></Button>
        <Button number={3}></Button>
      </div>
      <AnimalList list={animal}></AnimalList>
      <div className="counter">
      <h1>Counter</h1>
      <ControlButton></ControlButton>
<CheckList data = {task}></CheckList>
    </div>
    <div className="accordion">
      <h1>Accordion:</h1>
      
    </div>
    </Container>
    
  );
  {/*
    <Container styles={{ border: '3px solid black', margin: '2rem' }}>
      <AnimalList list={animal}></AnimalList>
</Container>)*/}
}

export default App;
